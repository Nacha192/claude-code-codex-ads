# Shot-level communication

Source: [inference-sh/skills / guides/video/storyboard-creation/SKILL.md](https://github.com/inference-sh/skills/blob/becc25649700d5457772a00e5143e28ccf9e5afa/guides/video/storyboard-creation/SKILL.md). Captured 2026-09-06. Origin: Portable/other source; host adapter required. Repository stars at capture: 726. Repository API license: UNKNOWN. Revision: `becc25649700d5457772a00e5143e28ccf9e5afa`. Entrypoint SHA-256: `c91fc8decd085367b6965c539e8b41d2da2b39ab2592b91cb73a9c3d3dd168b9`.

## Original integrated adaptation

Purpose: Specify framing, action and scene purpose so visual production can be reviewed before full rendering.

Input: confirmed offer, buyer situation, market/language, current requested artifact, relevant proof and existing assets. Ask only for missing essentials. Read the [local workflow](../references/video-prompting.md) and [shared contract](../references/core.md).

1. Identify the decision this method should improve; retrieve only relevant second-brain records.
2. Apply the purpose above to the actual product and evidence. Make an original output, not a copied competitor or source example.
3. Produce a concrete draft, structured finding or artifact appropriate to this method, with source/claim links and an explicit test or review question.
4. Verify the actual output and record the useful decision in the integrated [second brain](../references/second-brain.md). Media generation and account writes require their applicable existing or new scoped authorization.

## Codex execution adapter

Detect an actual video capability before promising one, then generate only against a recorded approval and inspect the returned file. Resolve project files from the active workspace and internal references from this skill. Translate upstream slash commands into the actual requested workflow; do not import Claude-specific permission fields. In solo mode, complete available work yourself.

## Claude Code execution adapter

Detect a connected video provider or rendering toolchain; when none exists, produce direction and prompts and say plainly that nothing was generated. Resolve the same portable artifact contract in the active project. Replace Codex app/tool assumptions with observed Claude tools. Solo mode never auto-launches a Codex process.

## Deliberate changes and limits

Generated storyboard panels consume resources and require the media approval gate. This is an original functional adaptation and source review, not a verbatim translation of the whole upstream skill. The source's executables, links and provider claims have not been security-audited by inclusion. Inspect any dependency before choosing to install it. No source grants account access or additional user authority.
