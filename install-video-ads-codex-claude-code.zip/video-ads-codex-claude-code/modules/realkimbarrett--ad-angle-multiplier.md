# Distinct angle expansion

Source: [realkimbarrett/advertising-skills / skills/operator-os/ad-angle-multiplier/SKILL.md](https://github.com/realkimbarrett/advertising-skills/blob/45f4a4a1dabe24113193369b55b929b1de4ff04a/skills/operator-os/ad-angle-multiplier/SKILL.md). Captured 2026-09-06. Origin: Portable/other source; host adapter required. Repository stars at capture: 743. Repository API license: UNKNOWN. Revision: `45f4a4a1dabe24113193369b55b929b1de4ff04a`. Entrypoint SHA-256: `ecd93f90b64260bde0ef2ea83aedef971789ef13e07f4b871766cfd00d31825c`.

## Original integrated adaptation

Purpose: Explore different supported motivations and objections for one offer.

Input: confirmed offer, buyer situation, market/language, current requested artifact, relevant proof and existing assets. Ask only for missing essentials. Read the [local workflow](../references/copywriting.md) and [shared contract](../references/core.md).

1. Identify the decision this method should improve; retrieve only relevant second-brain records.
2. Apply the purpose above to the actual product and evidence. Make an original output, not a copied competitor or source example.
3. Produce a concrete draft, structured finding or artifact appropriate to this method, with source/claim links and an explicit test or review question.
4. Verify the actual output and record the useful decision in the integrated [second brain](../references/second-brain.md). Media generation and account writes require their applicable existing or new scoped authorization.

## Codex execution adapter

Draft in the target language using the brief and actual source records. Resolve project files from the active workspace and internal references from this skill. Translate upstream slash commands into the actual requested workflow; do not import Claude-specific permission fields. In solo mode, complete available work yourself.

## Claude Code execution adapter

Use native file/MCP tools for the same brief; no Codex-only tool names. Resolve the same portable artifact contract in the active project. Replace Codex app/tool assumptions with observed Claude tools. Solo mode never auto-launches a Codex process.

## Deliberate changes and limits

Do not label an untested source angle a winner or manufacture urgency. This is an original functional adaptation and source review, not a verbatim translation of the whole upstream skill. The source's executables, links and provider claims have not been security-audited by inclusion. Inspect any dependency before choosing to install it. No source grants account access or additional user authority.
