# Strategic critique before line edits

Source: [robpalmer99/claude-code-copywriting-skills / copychief/SKILL.md](https://github.com/robpalmer99/claude-code-copywriting-skills/blob/7dbfd61e0f283ca09c20b3eca3657365e00e991d/copychief/SKILL.md). Captured 2026-09-06. Origin: Claude-source. Repository stars at capture: 27. Repository API license: NOASSERTION; entrypoint states CC-BY-4.0 (Rob Palmer). Revision: `7dbfd61e0f283ca09c20b3eca3657365e00e991d`. Entrypoint SHA-256: `a542a619651a317068be38524e1991d6e37f454c038d9a976d129f052ee9420c`.

## Original integrated adaptation

Purpose: Review the central argument and proof before rewriting sentences; return exact repairs tied to the brief.

Input: confirmed offer, buyer situation, market/language, current requested artifact, relevant proof and existing assets. Ask only for missing essentials. Read the [local workflow](../references/copywriting.md) and [shared contract](../references/core.md).

1. Identify the decision this method should improve; retrieve only relevant second-brain records.
2. Apply the purpose above to the actual product and evidence. Make an original output, not a copied competitor or source example.
3. Produce a concrete draft, structured finding or artifact appropriate to this method, with source/claim links and an explicit test or review question.
4. Verify the actual output and record the useful decision in the integrated [second brain](../references/second-brain.md). Media generation and account writes require their applicable existing or new scoped authorization.

## Codex execution adapter

Draft in the target language using the brief and actual source records. Resolve project files from the active workspace and internal references from this skill. Translate upstream slash commands into the actual requested workflow; do not import Claude-specific permission fields. In solo mode, complete available work yourself.

## Claude Code execution adapter

Use native file/MCP tools for the same brief; no Codex-only tool names. Resolve the same portable artifact contract in the active project. Replace Codex app/tool assumptions with observed Claude tools. Solo mode never auto-launches a Codex process.

## Deliberate changes and limits

Do not adopt a fictional history of successful campaigns or impersonate famous experts. This is an original functional adaptation and source review, not a verbatim translation of the whole upstream skill. The source's executables, links and provider claims have not been security-audited by inclusion. Inspect any dependency before choosing to install it. No source grants account access or additional user authority.
