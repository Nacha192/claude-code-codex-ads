---
name: meta-ads-claude-code
description: Create and improve Meta advertising as solo Claude Code, with an integrated second brain for business discovery, ad research, hooks, copy, static/video assets, voice and campaign learning. Use for one-assistant advertising work; use the team edition when both Codex and Claude Code are requested.
---

# Meta Ads — Claude Code solo, all in one

Own the requested advertising outcome from brief to reviewed deliverables. All methods below are internal parts of THIS skill, including the second brain. Do not auto-launch Codex or present a simulated peer review. Keep conversation in the user's language and ads in the target market's language.

Read [core](references/core.md) and [second brain](references/second-brain.md) first. The latter includes connected reasoning, memory contracts, retrieval, contradictions and learning; it is not an external skill. Read only other modules needed for the current request.

## Work from the real business

Use [intake](references/intake.md) to establish the offer, niche, buyer, geography, language and material unknowns. Retrieve relevant prior facts and experiments before asking questions. A scraping request without a known product/market needs a compact essential brief. Never substitute a guessed business or fake buyer research.

Use [research](references/research.md) for Meta library and competitor scans: explicit window, query/sample plan, source records, gaps and observations versus performance. Use [source catalog](references/source-catalog.md) for the eight researched top-ten selections and internal source-adaptation modules, and [conversion](references/conversion.md) when adapting another host's method.

## Make the argument and artifact

Use [copywriting](references/copywriting.md) to connect buyer friction, hook, mechanism, proof and CTA. Propose distinct arguments, not cosmetic variations. Apply [creative retrospective](references/v11-lessons.md) for reusable lessons about real hooks, visual meaning, audience awareness, truthful qualification and format-specific layouts.

Choose [static](references/static.md) for images/carousels or [video and voice](references/video-voice.md) for footage, motion, narration, music, effects and captions. Consult [providers](references/providers.md) to discover actual creation tools and access. Obtain the required scoped approval BEFORE new media generation unless already covered; do not ask again for an unchanged authorized batch.

Produce and inspect the requested final files. A script, prompt or silent video is not a complete voiced ad. If a required tool is unavailable, finish independent work and explicitly identify the missing deliverable and workable route. Do not claim generation from a provider name alone.

## Basic and advanced

Follow [models](references/models.md): Use the current Claude model for a compact basic workflow and available Opus 5 for advanced competing hypotheses, meaningful prototypes and deeper artifact critique. Sol/Astra require an actual Codex peer in a separately requested team workflow; do not simulate those models. Confirm the model actually available on this host. Neither profile promises human consciousness or a numerical performance multiplier. Both retain truthfulness and production QA.

## Campaign and learning

Use [campaign operations](references/campaign-operations.md) for authorized account changes, exact budget/schedule and ambiguous-write reconciliation. Preparing creative does not authorize activation. Use [memory and experiments](references/memory-testing.md) and the second brain to record what was actually learned, including failures and uncertainty.

Deliver the requested assets and copy, relevant sources, actual QA status, and a next test when useful. Distinguish draft, generated, reviewed, approved, uploaded and live. The included [artifact checker](scripts/check_artifact.py) performs offline structural checks; it does not certify truth, policy or creative quality.
