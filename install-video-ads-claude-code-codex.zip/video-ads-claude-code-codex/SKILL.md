---
name: video-ads-claude-code-codex
description: Complete a video advertising mission jointly with real Claude Code and Codex, launched from Claude Code. Includes the integrated second brain, retention research, hooks, scripts, storyboards, voice, music, generation prompting, assembly, cross-review and campaign learning. Use when both assistants are requested for video ad work.
---

# Video ads: complete team, launched from Claude Code

You are Claude Code; your real peer is Codex. Jointly complete the requested video mission. This is a full all-in-one creative skill, not a message dispatcher. Every research, writing, voice, production and second-brain module is INSIDE this package. Do original work on both sides and cross-review actual artifacts. Keep conversation in the user's language and ads in the target market's language.

Read [scope](references/scope.md), [core](references/core.md), [integrated second brain](references/second-brain.md) and [team procedure](references/team.md). Discover the installed Agent Duet bridge and read its actual protocol and command reference. Use one agreed task-local bus and an explicit handoff. On the first task in a project, confirm the Python interpreter through [runtime](references/runtime.md) before either side runs a script, and ask before installing anything. Do not fabricate the peer, spawn a Claude subagent pretending to be Codex, or treat an inactive message log as an active collaborator.

## Establish who can actually do what

Neither side arrives with a video model, and Claude Code has none built in. Exchange **observed** capability before dividing the work: connected video provider and its real model names, speech tool, rendering toolchain, research access, account permissions, and what each side cannot do. A capability claimed from a connector's name is not a capability.

This is the whole reason the team edition exists, so use the three fallbacks explicitly and say which one you are using:

**Access.** One side has the tool, the other does not. Hand off the approved brief, the exact inputs, the provider and account scope and the remaining ceiling. The receiving side verifies tool and account state before calling, and reports what came back. Tool access never enlarges permission.

**Comprehension.** One side has understood an instruction the other has not. The one who understood rewrites it as a clearer prompt and sends that, naming the ambiguity it resolved. Repeating the same sentence more politely is not a handoff.

**Context.** One side holds the brand, market, register or the history of what was already rejected. Send the context itself, not a conclusion drawn from it. If neither side has it, ask the user in one compact batch rather than guessing, and put the answer where both can read it.

## Complete the video work

Before splitting any role, run the blind pass in [working as two](references/team.md): both sides write the buyer's problem, the blocking obstacle and three concepts alone, put them on the bus at the same time, and only then read each other. Two assistants that never disagree cost twice as much as one and are worth less. The synthesis records what was agreed independently, what was not, and the cheapest test that settles it. Roles come after that, never before.

1. Retrieve business and lessons through [second brain](references/second-brain.md); use [intake](references/intake.md) for the missing essentials only, including duration and the blocking register question.
2. Use [research](references/research.md) and [studying video that already works](references/video-scraping.md) for the three pulls of thirty over three months. Split the pulls between the two sides, then merge evidence and contradictions before choosing angles. A library proves an ad ran, never that it worked.
3. Use [source catalog](references/source-catalog.md) for the six top-ten selections and internal modules; [conversion](references/conversion.md) maps a method onto each real host.
4. Build the argument with [retention](references/video-retention.md), [hooks](references/hooks.md) and [copywriting](references/copywriting.md), informed by the [creative retrospective](references/v11-lessons.md). Both sides score at least three hooks on the seven criteria before either sees the other's, per the blind pass. Lock the thirteen fields of the creative lock in the manifest.
5. Follow [the production contract](references/production-contract.md) phase by phase and keep one `motion-project.json`, per [the manifest](references/motion-manifest.md). Choose a look with [art direction](references/art-direction.md) rather than applying a house style. Then [video models](references/video-models.md), [prompting](references/video-prompting.md), [voice](references/video-voice.md), [music](references/video-music.md), [assembly](references/video-assembly.md) and [real production](references/live-action.md) when filming beats generating. Every requested ratio gets its own composition, and the mandatory ratios are the ones in the brief.
6. Before NEW media generation, present provider, model, account, variants, duration, formats and ceiling, and obtain approval unless already covered. Designate one generator for a given scope so the same batch is not produced twice. Approval to create does not authorize campaign activation. The engine actually detected goes in the manifest with `detected: true`; a pipeline that was assumed is refused.
7. Run the correction loop on the real export, not the plan. `scripts/inspect_video.py` decodes each file and returns measurements and findings; [creative QA](references/creative-qa.md) is the separate human grid and **the side that did not build it runs that one**. Fix the source, re-render only the affected formats, cap at three passes. Record who inspected which version, with which tools, against which hash. A consultant that was not given the file cannot attest to it.
8. Follow [campaign operations](references/campaign-operations.md) for authorized remote actions; the designated executor reconciles ambiguous writes from authoritative state. Use [experiments](references/memory-testing.md) and the second brain to connect outcomes to creative genealogy and uncertainty.

## Work mode and delivery

Read [models](references/models.md). Basic and advanced are modes, not model tiers: each side runs the mode the task needs on whichever model its host actually exposes. Announce the real model and mode you are running. No simulated model switching and no guaranteed quality multipliers.

Deliver against the [output standard](references/output-standard.md): the file, captions and transcript, the script, the voice and settings manifest, rights notes, review status and useful next tests. Run the included [artifact checker](scripts/check_artifact.py) on every artifact that crosses the bridge and on any generation request; a non-zero exit stops the handoff. It refuses credential-shaped values in anything sent to the peer. With no interpreter, say so on the bridge: an unchecked artifact is not a reviewed one. Keep private business data out of the public skill, and close the bridge under its protocol only after real handoffs, reviews and acknowledgements are complete.


## What makes this the team edition rather than a claim about it

- **Both assistants are real.** A message file that stays empty is not a
  collaboration, and an absent peer is never simulated or narrated.
- **A real capability card from each side**, per [providers](references/providers.md).
  Two sides with different tools is the whole point; assuming they match wastes it.
- **Every artifact version names its author and its reviewer**, and the review
  carries the `sha256` of the exact file that was read.
- **A review dies when the file changes.** If the artifact is edited after the
  review, that review no longer applies to anything and the new version is reviewed
  again. Carrying it forward is how an unreviewed cut ships with a signature on it.
- **The fallback is explicit.** If the second agent genuinely cannot be reached,
  say so, fall back to the solo skill, and deliver. That is a legitimate outcome.
  **It is never described as a cross-review.** One assistant that checked its own
  work is one assistant that checked its own work, whatever the pack is called.

## One pass, and the pass that checks it

The first delivery is the deliverable, not a draft with a question attached.
[One shot](references/one-shot.md) is the contract: ask everything blocking in a
single message before starting, state every assumption where it will be read,
ship every channel the format has, and never narrow the scope in silence.

[Quality control](references/quality-control.md) is the pass that decides
whether that is true rather than intended, and it is run on the exported
artifact. A script exiting zero is not that pass. It read the manifest you
wrote, not the pixels anyone will see.

## Filming it, when that is the right answer

A real person filming a real product is still the strongest video ad on most
accounts, and it is the option most often skipped. [Real production](references/live-action.md)
covers the identity release, the creator brief, the coverage that makes an edit
possible at all, the four things that ruin footage, and the usage window after
which the ad has to come down.
